<?php namespace App\Model;


use http\Client\Curl\User;


class tables extends DB
{
    public  $paths = array("user");


}