<?php


namespace App\Model;



class  DB implements interface1
{

    static protected $con ='';

    public  $paths = array();
    public function __construct()
    {

        $require = require __DIR__ . '/../config.php';
        try {
            self::$con = new \PDO("mysql:host=localhost;dbname={$require['DB']['dbname']}",$require['DB']['username'],$require['DB']['password']);
        }

        catch (\Exception $e)
        {
            echo 'Error :'.$e->getMessage();
        }




    }

     public function select()
    {




        $stmt = self::$con ->prepare("select *from {$this->paths[0]}");

        $stmt->execute();
        $result = $stmt->fetchAll(\PDO::FETCH_OBJ);
        return $result;

    }
}