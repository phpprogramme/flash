<?php


namespace App\Model;


interface interface1
{


     public function select();



}