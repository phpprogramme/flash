<?php


namespace App\helper;





class Validation
{

    private $data;
    private $error;

     public function make(Array $data , Array $rules)

    {


        $valid = true;

         $this->data = $data;

        foreach ($rules as $item=>$rulest)
        {
            $rulest = explode('|',$rulest);

            // Get data
            foreach ($rulest as $rule)
            {

                $pos = strpos($rule , ':');



                if ($pos !==false)
                {

                    $parametr = substr($rule , $pos+1);
                    $rule = substr($rule , 0 , $pos);
                }

                else
                {
                    $parametr =  "";
                }

                $method_name = ucfirst($rule);

                $value = isset($data[$item]) ? $data[$item] : null;


                if (method_exists($this , $method_name))
                {

                    // یعنی اعتبار لازم نداشت
                    if ($this->{$method_name}($item,$value , $parametr)== false)
                    {
                        $value = false;
                        break;

                    }

                }

            }
        }




        return $valid;


    }


    public function geterror()
    {
        return $this->error;
    }

     private function required($item , $value)
     {
         if (strlen($value) == 0) //یعنی خالی بود مقادیر ما فیلدما
         {
             $this->error[$item][] = "پرکردن فیلد {$item} الزامی می باشد";
             return false;
         }
         return true;
    }

    private function confirm($item , $value , $param)
    {

        $oprginal = isset($this->data[$item]) ? $this->data[$item] : null;
        $confirm = isset($this->data[$param]) ? $this->data[$param] : null;

        if ($oprginal !== $confirm)
        {
            $this->error[$item][] = "فیلد {$item} با فیلد {$param} برابر نیست";
            return false;
        }
            return true;
    }

    private function email($item , $value)
    {

        if (!filter_var($value , FILTER_VALIDATE_EMAIL))
        {


                $this->error[$item][] = "فرمت {$item} وارد شده صحیح نمی باشد";
                return false;


        }

        return true;
    }

    private function max($item , $value , $param)
    {

        if ( strlen($value )> $param)
        {
            $this->error[$item][] = "طول فیلد {$item} بیشتر {$param} می باشد";
            return false;
        }
        else true;
    }

    private function min($item , $value , $param)
    {
        if ( strlen($value) < $param)
        {
            $this->error[$item][] = "طول فیلد {$item} کمتر {$param} می باشد";
            return false;
        }

        return false;
    }



}