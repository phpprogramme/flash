<?php


namespace App\Controller;


use App\helper\Validation;
use Plasticbrain\FlashMessages\FlashMessages;

class Controller
{

    /**
     * @var FlashMessages
     */
    public $flash;

    public function __construct()
    {
        $this->flash = new FlashMessages();

    }

    /**
     * @param $data
     * @param $rules
     * @return bool
     */
    public function Validation($data , $rules)
    {
        /** @var TYPE_NAME $validation */
        $validation = new Validation();

        $valid = $validation->make($_POST , $rules);

        if (! $valid)
        {
            foreach ($validation->geterror() as $erorr){
                $this->flash->error($erorr[0]);
            }

            return false;

        }


        return true;

    }

}