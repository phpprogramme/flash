<?php namespace App\Controller;


use App\Model\DB;
use App\Model\tables;

class HomeController
{
    function index()
    {
        $db= new tables();
        var_dump($db->select());
    }
}


?>
