<?php


namespace App\Controller;




class UserController extends Controller
{

    public function register()
    {
        if($_SERVER['REQUEST_METHOD'] != 'POST')
            return;

        $rules = [
            'name' => 'required',
            'email' => 'required|email|unique:user',
            'password' => 'required|min:6|max:20',
            'confirm_password' => 'required|confirm:password'
        ];



//        if(! $valid) {
//            var_dump($validation->getErrors());die;
//        }
        if( ! $this->Validation($_POST , $rules)) {
            return;
        }

    }

}