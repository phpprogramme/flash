<?php


return [

    'DB'=>[
        'servername'=>'localhost',
        'username'=>'root',
        'password'=>'',
        'dbname'=>'oop'
    ]
];