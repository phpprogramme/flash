<!-- jQuery -->
<script src="public/js/jquery.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="public/js/bootstrap.min.js"></script>

</body>

</html>
