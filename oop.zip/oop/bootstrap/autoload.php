<?php
// Start a Session
if (!session_id()) @session_start();

require __DIR__  .'/../vendor/autoload.php';

/** @var TYPE_NAME $flash */
$flash =  new \Plasticbrain\FlashMessages\FlashMessages();

